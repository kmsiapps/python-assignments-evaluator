def foo(c):
    print(c + 'foo')

x = input('Enter a character:')
foo(x)
