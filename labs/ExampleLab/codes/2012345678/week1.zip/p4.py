def bar():
    print('bar')

bar()
