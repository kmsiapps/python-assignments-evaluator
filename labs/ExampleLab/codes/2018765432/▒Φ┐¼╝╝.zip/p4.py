print('babarian')
